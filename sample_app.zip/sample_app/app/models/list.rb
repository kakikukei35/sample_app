class List < ApplicationRecord
  has_one_attached :image
end
